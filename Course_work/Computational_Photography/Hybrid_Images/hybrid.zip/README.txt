Hybrid Images for CS691B Computational Photography Assignment #1
Wentian Zhou
9/13/15

I. How to use the code

	1. In this folder, double click hybrid_image_starter.m.
	2. Choose sample image sets: comment or uncomment in line 8 to line 20
	3. Set images to gray scale by uncommenting line 20 and 21, and change the FUNCTION in line 37 to "hybridImage". default: color images
	4. Change cut off frequencies in line 35 and 36 according to the description of each sample image set in webpage. default: cutoff_low =5, cutoff_high=6 for sample Steve Gates.
	5. Run program by press F5.
	6. Select two points of each image to align images. (e.g. eyes).
	7. Select two diagonal points to crop produced hybrid images.
	8. Produced hybrid image will present in figure 1.
	9. Figure 2,3 are the aligned original images.
	10. Figure 4,5 are the spectrum before filtering process.
	11. Figure 6,7 are the filtered images.
	12. Figure 8,9 are the spectrum after filtering process.
	13. Figure 10 is the gaussian pyramids and figure 11 is the laplacian pyramids.

