function [ im12 ] = hybridImage( im1, im2, cutoff_low, cutoff_high )
%[ im12 ] = hybirdImage( im1, im2, cutoff_low, cutoff_high )
%Creat hybrid images
%Output:
%im12: hybrid Image
%Input:
%Im1: First image, low frequency component will be preserved
%im2: Second image, High frequency component will be preserved
%cutoff_low: cut-off frequency for low-pass filter
%cutoff_high: cut-off frequency for high-pass filter

%Created by Wentian Zhou
%Time Created:9/3/15
%Last Modified: 9/3/15

figure
imagesc(log(abs(fftshift(fft2(im1(:,:,1))))));
figure
imagesc(log(abs(fftshift(fft2(im2(:,:,1))))));

H1 = fspecial('gaussian',cutoff_low*3+1,cutoff_low);
H2 = fspecial('gaussian',cutoff_high*3+1,cutoff_high);
filter_im1 = imfilter(im1,H1,'symmetric','conv' );
figure
imshow(filter_im1,[],'border','tight'); %colormap gray
filter_im2 = imfilter(im2,H2,'symmetric','conv' );
low_frequency = filter_im1;
high_frequency = im2 - filter_im2;
figure
imshow(high_frequency,[],'border','tight'); %colormap gray
im12 = low_frequency+high_frequency;

figure
imagesc(log(abs(fftshift(fft2(low_frequency(:,:,1)))))); 
set(gca,'position',[0 0 1 1],'units','normalized')
v = caxis;
figure
imagesc(log(abs(fftshift(fft2(high_frequency(:,:,1)))))); 
caxis(v);
set(gca,'position',[0 0 1 1],'units','normalized')

end

