%% Computataional Photography Assignment 1
% Hybird Images



%Created by Wentian Zhou
%Date Created:9/3/15
%Last Modified: 9/3/15

clear
clc
close all
warning off

%Date Input
I1 = double(imread ('cat.jpg'))/255;
%I1_gray = rgb2gray(I1);

[m,n,z] = size(I1);
%Generate Filter 
H1 = fspecial('gaussian',2*3+1,2);

filteredI1 = imfilter(I1,H1,'symmetric','conv');
%aa = I1 - filteredI1;
figure;
imshow([filteredI1],[],'border','tight')


figure;
imagesc(log(abs(fftshift(fft2(I1(:,:,1))))));
set(gca,'position',[0 0 1 1],'units','normalized')
v = caxis;
figure;
imagesc(log(abs(fftshift(fft2(filteredI1(:,:,1)))))); 
caxis(v);
set(gca,'position',[0 0 1 1],'units','normalized')

