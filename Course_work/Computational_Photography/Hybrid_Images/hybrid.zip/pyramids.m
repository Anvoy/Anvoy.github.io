function pyramids( im, level )
%pyramids( im, level )
% Compute and display Gaussian and Laplacian Pyramids
%Input:
%im: Input image
%level: Pyramid level
%Create by Wentian Zhou
%Date Created: 9/6/15
%Date Modified: 9/6/15
%Version 1.0


%Guassian Pyramid
gauss_pyra = gausPyra(im,level+1);
figure;
for i = 1:level
subplottight(2,ceil((level+1)/2),i); 
imshow(gauss_pyra{i},[],'Border','tight'); %title(['level ' num2str(i)]);
end
lapla_pyra = laplaPyra(gauss_pyra,level);
figure
for i = 1:level
subplottight(2,ceil((level+1)/2),i);
imshow(lapla_pyra{i},[],'Border','tight'); %title(['level ' num2str(i)]);
end
end


function pyra_out = gausPyra(im,level)
H = fspecial('gaussian',5,1);

pyra_out = cell(level,1);
pyra_out{1} = im;

for i = 2: level
    pyra_up = pyra_out{i-1};
    for j =1:size(im,3)
        im_filtered = imfilter(pyra_up (:,:,j),H,'replicate','same','conv');
        im_temp(:,:,j) = im_filtered(1:2:size(pyra_up ,1),1:2:size(pyra_up ,2));
    end
    pyra_out{i} = im_temp;
  clear im_temp
end

end
function pyra_out = laplaPyra(gauss_pyra,level)
    [~,~,t] = size(gauss_pyra{1});
    for i = 1:level
        [m,n,~] = size (gauss_pyra{i});
        for j = 1:t
                im_temp = imresize(gauss_pyra{i+1}(:,:,j),[m,n],'bilinear');
                pyra_out{i}(:,:,j) = gauss_pyra{i}(:,:,j) - im_temp;
        end
        clear im_temp
    end
end
function h = subplottight(n,m,i)
    [c,r] = ind2sub([m n], i);
    ax = subplot('Position', [(c-1)/m, 1-(r)/n, 1/m, 1/n]);
    if(nargout > 0)
      h = ax;
    end
end

